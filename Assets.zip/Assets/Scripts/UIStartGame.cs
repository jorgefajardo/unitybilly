using TMPro;
using UnityEngine;

public class UIStartGame : MonoBehaviour
{
    public Game Game;
    public TextMeshProUGUI Timer;
    public GameObject StartGame;
    private int startTime;

    public void Start()
    {
        startTime = Game.StartTime;
        Timer.text = startTime.ToString();
        Invoke("ReduceTime", 1);
    }

    private void ReduceTime()
    {
        if (startTime == 0)
        {
            Game.StartGame();
            StartGame.SetActive(true);
            gameObject.SetActive(false);
            return;
        }

        startTime--;
        Timer.text = startTime.ToString();
        Invoke("ReduceTime", 1);
    }
}
