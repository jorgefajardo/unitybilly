using UnityEngine;

public class Player : MonoBehaviour
{
    public Game Game;
    public float Speed;
    public Vector2 JumpImpulse;

    private Rigidbody2D rb;
    private Animator animator;
    private Vector3 originalLocalScale;
    private bool isGrounded;

    private void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
        originalLocalScale = transform.localScale;
    }

    private void Update()
    {
        if (Game.IsGameStarted && !Game.IsGameOver)
        {
            if (isGrounded && Input.GetKeyDown(KeyCode.Space))
            {
                rb.AddForce(Vector2.up * JumpImpulse, ForceMode2D.Impulse);
                animator.SetBool("Jump", true);
            }

            float input = Mathf.Round(Input.GetAxis("Horizontal"));
            transform.Translate((input * Speed * Time.deltaTime * Vector3.right));

            if (input != 0)
            {
                Vector3 localScale = originalLocalScale;

                if (input < 0)
                    localScale.x *= -1;
                else
                    localScale.x *= 1;

                transform.localScale = localScale;
                animator.SetFloat("Walking", Mathf.Abs(input));
            }
            else
            {
                animator.SetFloat("Walking", -1);
            }

            if(transform.position.y < 1)
            {
                Game.GameOver();
            }
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if(!isGrounded)
        {
            isGrounded = collision.gameObject.CompareTag("Ground");
            animator.SetBool("Jump", false);
        }
    }

    private void OnCollisionStay2D(Collision2D collision)
    {
        if (!isGrounded)
        {
            isGrounded = collision.gameObject.CompareTag("Ground");
            animator.SetBool("Jump", false);
        }
    }

    private void OnCollisionExit2D(Collision2D collision)
    {
        isGrounded = false;
    }
}