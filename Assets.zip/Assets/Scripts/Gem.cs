using UnityEngine;

public class Gem : MonoBehaviour
{
    public Game Game;
    public AudioSource PickupSound;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        Game.AddGem();
        PickupSound.Play();
        Destroy(GetComponent<Collider2D>());
        transform.localScale = Vector3.zero;
    }
}
