using UnityEngine;

public class PlayerCamera : MonoBehaviour
{
    public Transform Player;
    public Vector2 MinMax;

    private void Update()
    {
        float x = Mathf.Clamp(Player.position.x, MinMax.x, MinMax.y);
        Vector3 position = transform.position;
        position.x = x;
        transform.position = position;
    }
}