using UnityEngine;

public class Game : MonoBehaviour
{
    public AudioSource Music;
    public AudioSource WinMusic;
    public AudioSource LoseMusic;
    private bool isGameStarted = false;
    private bool isGameOver = false;
    private int startTime = 2;
    private int gameTime = 10;
    private int gemsToWin = 7;
    private int gems = 0;

    public bool IsGameStarted
    {
        get => isGameStarted;
    }

    public int StartTime 
    {
        get => startTime; 
    }

    public int GameTime 
    { 
        get => gameTime; 
    }

    public int Gems
    {
        get => gems;
    }

    public int GemsToWin 
    {
        get => gemsToWin;
    }

    public bool IsGameOver 
    {
        get => isGameOver; 
    }

    public void StartGame()
    {
        isGameStarted = true;
        Music.Play();
    }

    public void GameOver()
    {
        isGameOver = true;

        if(gems >= gemsToWin)
        {
            WinMusic.Play();
        }
        else
        {
            LoseMusic.Play();
        }
    }

    public void AddGem()
    {
        gems++;
    }
}