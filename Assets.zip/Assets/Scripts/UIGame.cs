using TMPro;
using UnityEngine;

public class UIGame : MonoBehaviour
{
    public Game Game;
    public GameObject Win;
    public GameObject GameOver;
    public TextMeshProUGUI Timer;
    public TextMeshProUGUI Gems;
    private int gameTime;

    public void Start()
    {
        gameTime = Game.GameTime;
        Timer.text = "Time: " + gameTime.ToString();
        Invoke("ReduceTime", 1);
    }

    private void ReduceTime()
    {
        if (gameTime == 1 || Game.IsGameOver)
        {
            if(!Game.IsGameOver)
            {
                Game.GameOver();
            }

            if(Game.Gems < Game.GemsToWin)
            {
                GameOver.SetActive(true);
            }
            else
            {
                Win.SetActive(true);
            }

            return;
        }

        gameTime--;
        Timer.text = "Time: " + gameTime.ToString();
        Invoke("ReduceTime", 1);
    }

    private void Update()
    {
        Gems.text = "x" + Game.Gems;
    }
}
